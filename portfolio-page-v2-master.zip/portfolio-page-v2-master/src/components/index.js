export {default as Navigation_bar} from './Navigation_bar/Navigation_bar'
export {default as Mobile_Nav} from './Mobile_Navigation_bar/Mobile_nav'
export {default as Hero_section} from './Hero_section/Hero_section'
export {default as Intro_section} from './Intro_section/Intro_section'
export {default as Tech_stack_section_1} from './Tech_stack_section_1/Tech_stack_section_1'
export {default as Tech_stack_section_2} from './Tech_stack_section_2/Tech_stack_section_2'
export {default as Projects_section} from './Projects_section/Projects_section'
export {default as Footer_section} from './Footer_section/Footer_section'













